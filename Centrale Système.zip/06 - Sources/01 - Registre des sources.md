# Registre des sources

| ID | Source | Type | Emplacement | SHA-256 | Intégrité | Analyse | Notes |
|---|---|---|---|---|---|---|---|
| SRC-0001 | À renseigner | À renseigner | À renseigner | À calculer | Inconnue | Non commencée | |

## Règle

Les sources originales ne sont pas modifiées. Les analyses et annotations sont produites dans des notes séparées et reliées à la source.

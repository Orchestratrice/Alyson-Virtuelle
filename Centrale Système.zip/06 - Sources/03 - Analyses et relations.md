# Analyses et relations

Espace destiné aux analyses dérivées des sources et aux liens entre documents, concepts, preuves, témoins, décisions et projets.

## Règle

Une analyse n’est pas la source originale. Elle doit toujours indiquer ce qu’elle interprète, à partir de quelle source et avec quel niveau de confiance.

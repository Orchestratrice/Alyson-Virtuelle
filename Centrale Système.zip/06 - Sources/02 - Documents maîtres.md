# Documents maîtres

Un document maître donne la compréhension générale d’un secteur avant les détails des projets.

| Secteur | Document maître | Statut | Dernière validation | Projets liés |
|---|---|---|---|---|
| Architecture | À créer | À définir | À définir | |
| Documentation | À créer | À définir | À définir | |
| Ingénierie | À créer | À définir | À définir | |
| Design | À créer | À définir | À définir | |
| DevOps | À créer | À définir | À définir | |
| Données | À créer | À définir | À définir | |

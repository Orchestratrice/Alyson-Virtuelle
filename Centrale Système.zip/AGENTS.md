# Règles du Centre de planification et de conception

## Fonction

Ce dossier est la source documentaire de travail pour comprendre, planifier et concevoir. Les décisions validées et les informations canoniques doivent rester accessibles ici.

## Règles

1. Ne pas créer de solution technique avant d’avoir décrit le besoin.
2. Séparer vision, faits, hypothèses, questions, décisions et expérimentations.
3. Une information stable possède un emplacement canonique.
4. Ne pas écraser une source originale ; ajouter les annotations à côté.
5. Ne pas mélanger données personnelles, architecture universelle et projets sans lien explicite.
6. Ne pas considérer une idée comme une décision tant qu’elle n’est pas validée.
7. Les outils servent la structure documentaire ; ils ne la définissent pas seuls.
8. Toute procédure doit être testée avant d’être déclarée standard.
9. Documenter les décisions importantes avec leur raison et leurs conséquences.
10. Ne jamais enregistrer de mot de passe, clé API ou secret dans ce coffre.

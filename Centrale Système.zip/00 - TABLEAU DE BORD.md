# Centre de planification et de conception

> Point d’entrée unique pour préparer les systèmes, outils et méthodes.

## Situation actuelle

- **Phase :** clarification et conception
- **Statut :** à initialiser
- **Priorité actuelle :** comprendre la situation et établir une base documentaire durable
- **Prochaine action :** définir la vision et le périmètre du Centre

## Navigation

### Fondations

- [[01 - Fondations/01 - Vision du Centre]]
- [[01 - Fondations/02 - Concepts à clarifier]]
- [[01 - Fondations/03 - Périmètre]]

### Planification

- [[02 - Planification/01 - Phases]]
- [[02 - Planification/02 - Projets]]
- [[02 - Planification/03 - Priorités]]

### Conception

- [[03 - Conception/01 - Stack à clarifier]]
- [[03 - Conception/02 - Architecture conceptuelle]]
- [[03 - Conception/03 - Interfaces et tableaux de bord]]

### Méthodes

- [[04 - Méthodes/01 - Stratégies]]
- [[04 - Méthodes/02 - Méthodologies]]
- [[04 - Méthodes/03 - Workflows]]
- [[04 - Méthodes/04 - Templates]]

### Gouvernance

- [[05 - Gouvernance/01 - Décisions]]
- [[05 - Gouvernance/02 - Questions ouvertes]]
- [[05 - Gouvernance/03 - Journal de bord]]

### Sources

- [[06 - Sources/01 - Registre des sources]]
- [[06 - Sources/02 - Documents maîtres]]
- [[06 - Sources/03 - Analyses et relations]]

## Règle de travail

Une seule question ou décision importante à la fois. On clarifie d’abord ; on construit ensuite.

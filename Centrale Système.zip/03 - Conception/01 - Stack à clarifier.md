# Stack à clarifier

Ce document sert à comprendre les outils nécessaires avant de les choisir.

| Domaine | Besoin | Options à étudier | Décision | Statut |
|---|---|---|---|---|
| Documentation | Coffre et notes liées | Obsidian, autre | À définir | Ouvert |
| Versionnement | Historique et collaboration | Git, GitHub | À définir | Ouvert |
| Interface | Tableau de bord | À définir | À définir | Ouvert |
| Ingestion | Hash, extraction, métadonnées | À définir | À définir | Ouvert |
| Automatisation | Workflows et tâches | À définir | À définir | Ouvert |

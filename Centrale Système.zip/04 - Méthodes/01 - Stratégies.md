# Stratégies

Une stratégie décrit une direction et les choix qui permettent de l’atteindre.

## Modèle

- **Nom :**
- **Objectif :**
- **Problème traité :**
- **Principes :**
- **Contraintes :**
- **Options écartées :**
- **Décision :**
- **Critère de réussite :**

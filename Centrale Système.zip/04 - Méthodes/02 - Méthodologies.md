# Méthodologies

Une méthodologie décrit une manière reproductible de travailler.

## Modèle

- **Nom :**
- **Objectif :**
- **Quand l’utiliser :**
- **Entrées :**
- **Étapes :**
- **Sorties :**
- **Vérification :**
- **Limites :**
- **Version :**

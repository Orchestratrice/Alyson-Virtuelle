# Templates

Registre des modèles réutilisables du Centre.

| Template | Usage | Emplacement | Version | Statut |
|---|---|---|---|---|
| Document de décision | Formaliser une décision | À créer | 0.1 | Brouillon |
| Fiche de projet | Décrire un projet | À créer | 0.1 | Brouillon |
| Fiche de source | Documenter une source | À créer | 0.1 | Brouillon |
| Fiche de workflow | Décrire un processus | [[03 - Workflows]] | 0.1 | Brouillon |

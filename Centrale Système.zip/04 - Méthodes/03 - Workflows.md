# Workflows

Un workflow décrit le passage d’un état à un autre.

## Modèle

- **Nom :**
- **Déclencheur :**
- **Entrée :**
- **Étapes :**
- **Responsable :**
- **Validation humaine :**
- **Sortie :**
- **Journalisation :**
- **Gestion des erreurs :**

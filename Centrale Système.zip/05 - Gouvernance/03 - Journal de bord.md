# Journal de bord

## Ouverture du Centre

Création d’un coffre documentaire local destiné à la planification, la conception et la clarification des systèmes, outils, stratégies, méthodologies, templates et workflows.

Le Centre est conçu pour conserver une mémoire de travail durable en dehors de la mémoire interne d’un agent.

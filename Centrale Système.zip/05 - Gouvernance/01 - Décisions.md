# Décisions

| ID | Date | Décision | Raisons | Conséquences | Statut |
|---|---|---|---|---|---|
| DEC-0001 | À renseigner | Créer ce Centre de planification et de conception | Besoin d’une documentation durable et d’un espace de clarification | Base de travail centralisée | Proposition |

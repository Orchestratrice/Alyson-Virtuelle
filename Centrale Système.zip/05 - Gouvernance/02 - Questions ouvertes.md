# Questions ouvertes

| ID | Question | Pourquoi elle compte | Bloquante ? | Réponse / décision |
|---|---|---|---|---|
| Q-0001 | Quel est le périmètre exact du Centre ? | Évite la dispersion | Oui | À renseigner |
| Q-0002 | Quelle est la relation exacte avec Brain In A Box ? | Sépare conception et produit | Oui | À renseigner |
| Q-0003 | Quel stack doit être clarifié en premier ? | Oriente les recherches | Non | À renseigner |

# Concepts à clarifier

| Concept | Définition actuelle | Statut | Questions |
|---|---|---|---|
| Brain In A Box | À renseigner | À clarifier | Quelle est sa fonction exacte ? |
| Orchestratrice | À renseigner | À clarifier | Quel est son périmètre ? |
| Centre de planification | Espace de préparation et de conception | Proposition | Qu’est-ce qui doit y être canonique ? |
| Projet | À renseigner | À clarifier | Quelle structure minimale doit-il avoir ? |
| Source de vérité | À renseigner | À clarifier | Où se trouve la version à jour ? |

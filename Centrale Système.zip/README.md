# Centre de planification et de conception

Coffre documentaire central pour clarifier, planifier et concevoir les outils, systèmes et méthodes avant leur mise en œuvre.

## Point d’entrée

- [[00 - TABLEAU DE BORD]]

## Rôle du coffre

Ce coffre sert à conserver une source durable de travail pour :

- expliquer clairement les concepts ;
- planifier les phases et projets ;
- clarifier le stack ;
- documenter les stratégies ;
- concevoir les méthodologies ;
- créer des templates ;
- définir les workflows ;
- enregistrer les décisions ;
- conserver les sources et le contexte.

## Règle de séparation

Ce coffre est un centre de planification et de conception. Il ne devient pas automatiquement le dépôt de données personnelles, le système final ou l’archive de tous les projets existants.
